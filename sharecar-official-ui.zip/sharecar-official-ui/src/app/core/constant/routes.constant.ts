export const STATIC_ROUTES = {
  /**樣板頁 */
  TEMPLATE: 'template',
  /**服務說明頁 */
  DESCRIPTION: 'description',
  /**據點查詢頁 */
  AREA_QUERY: 'area-query',
  /**Q&A */
  FAQ: 'faq',
  /**聯絡我們 */
  CONTACT: 'contact'
}
