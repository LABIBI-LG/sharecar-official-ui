export interface Dropdown {
  name: string;
  code: string | number;
}
