export const environment = {
  production: false, // 或者 true
  channel: 'sharecar-official-ui'
};
