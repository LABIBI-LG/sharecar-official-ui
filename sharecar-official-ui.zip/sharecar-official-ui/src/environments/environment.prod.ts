export const environment = {
  production: true,
  channel: 'sharecar-official-ui'
};
